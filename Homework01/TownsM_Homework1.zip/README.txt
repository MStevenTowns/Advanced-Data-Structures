All of these programs must be run with python 3, they were tested on
Python 3.5.2

Aditionally computeSpans2.py requires stackDataAppend.py to be in the
same directory
