This the solution to the Signal Ranges Problem for the CSC325 final project
the full text of the problem can be seen here:
https://www.hackerearth.com/practice/data-structures/stacks/basics-of-stacks/practice-problems/algorithm/signal-range/

run the file "Towers.py" using Python 3 to see the ranges for towers with heights given in "Input.txt"
"Input.txt" contains some sample heights used durring testing.
It is required for "Towers.py" to run.
The first line tells how many test cases are included in the file.
the second line tells how many towers are in the next test case.
the third line is the space delimited list of heights for towers.
the next lines alternate between line 2 and line 3.
All values must be integers

the file "Stack.py" is required for "Towers.py" to run
this file contains the stack class used to track the highest towers encountered.